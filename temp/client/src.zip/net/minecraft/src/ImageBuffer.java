package net.minecraft.src;

import java.awt.image.BufferedImage;

public interface ImageBuffer {
	BufferedImage parseUserSkin(BufferedImage bufferedImage1);
}
