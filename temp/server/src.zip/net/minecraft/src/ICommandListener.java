package net.minecraft.src;

public interface ICommandListener {
	void getUsername();
}
