package net.minecraft.src;

public class ItemBoat extends Item {
	public ItemBoat(int i1) {
		super(i1);
		this.maxStackSize = 1;
	}
}
