package net.minecraft.src;

public class ItemSaddle extends Item {
	public ItemSaddle(int i1) {
		super(i1);
		this.maxStackSize = 1;
		this.maxDamage = 64;
	}
}
